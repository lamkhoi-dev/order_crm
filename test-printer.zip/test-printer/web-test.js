/**
 * 🌐 Web UI - Chọn máy in và test
 * 
 * Chạy: node web-test.js
 * Mở browser: http://localhost:3333
 */
import express from 'express';
import { EscPos, printRaw, listPrinters } from './printer-core.js';

const PORT = 3333;
const app = express();
app.use(express.json());

// --- API ---

// Lấy danh sách máy in
app.get('/api/printers', (_req, res) => {
  try {
    const printers = listPrinters();
    res.json({
      printers: printers.map(p => ({
        name: p.Name || p.name || '',
        status: p.PrinterStatus === 0 ? 'ready' : 'warning',
        statusText: p.PrinterStatus === 0 ? 'Sẵn sàng' : `Lỗi (${p.PrinterStatus})`,
      }))
    });
  } catch (err) {
    res.json({ printers: [], error: err.message });
  }
});

// In test — tờ giấy có tên máy in
app.post('/api/print-test', (req, res) => {
  const { printerName } = req.body;
  if (!printerName) return res.json({ success: false, error: 'Missing printerName' });

  try {
    const time = new Date().toLocaleString('vi-VN');
    const esc = new EscPos();

    esc.init()
      // Header
      .alignCenter()
      .bold(true).size(1, 1)
      .println('=== TEST IN ===')
      .bold(false).size(0, 0)
      .newLine()

      // Thông tin máy in
      .alignLeft()
      .bold(true).println('May in:').bold(false)
      .size(1, 0).alignCenter()
      .println(printerName)
      .size(0, 0).alignLeft()
      .newLine()
      .println(`Thoi gian: ${time}`)
      .line()

      // Test các kích thước
      .alignCenter()
      .println('--- Kich co chu ---')
      .size(0, 0).println('Nho (Normal)')
      .size(1, 0).println('Rong (Wide)')
      .size(0, 1).println('Cao (Tall)')
      .size(1, 1).println('To (Big)')
      .size(0, 0)
      .line()

      // Test canh lề
      .alignLeft().println('Canh trai')
      .alignCenter().println('Canh giua')
      .alignRight().println('Canh phai')
      .alignLeft()
      .bold(true).println('In dam (Bold)').bold(false)
      .line()

      // Kết quả
      .alignCenter()
      .bold(true).size(0, 1)
      .println('May in nay OK!')
      .size(0, 0).bold(false)
      .newLine(3)
      .cut();

    const ok = printRaw(printerName, esc.build());
    res.json({ success: ok, printerName });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// In phiếu bếp mẫu
app.post('/api/print-kitchen', (req, res) => {
  const { printerName, table, items, note } = req.body;
  if (!printerName) return res.json({ success: false, error: 'Missing printerName' });

  try {
    const time = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const orderId = `T${Date.now().toString().slice(-4)}`;
    const itemList = (items || []).filter(i => i.name);

    const esc = new EscPos();
    esc.init()
      .alignCenter()
      .bold(true).size(1, 1).println('PHIEU BEP').bold(false).size(0, 0)
      .newLine()
      .alignLeft()
      .println(`Don: #${orderId}`)
      .bold(true).size(1, 0).println(`Ban: ${table || 'Ban ?'}`).size(0, 0).bold(false)
      .println(`Gio: ${time}`)
      .line();

    for (const item of itemList) {
      esc.bold(true).size(0, 1).println(item.name).size(0, 0).bold(false)
         .println(`  SL: ${item.qty || 1}`);
    }

    if (note) esc.line().bold(true).println(`Ghi chu: ${note}`).bold(false);

    esc.line().alignCenter().println('--- HET ---').newLine(3).cut();

    const ok = printRaw(printerName, esc.build());
    res.json({ success: ok });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// In hoá đơn mẫu
app.post('/api/print-receipt', (req, res) => {
  const { printerName, table, items, paymentMethod } = req.body;
  if (!printerName) return res.json({ success: false, error: 'Missing printerName' });

  try {
    const time = new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    const orderId = `HD-${Date.now().toString().slice(-4)}`;
    const itemList = (items || []).filter(i => i.name);
    const total = itemList.reduce((s, i) => s + (i.price || 0) * (i.qty || 1), 0);

    const esc = new EscPos();
    esc.init()
      .alignCenter()
      .bold(true).size(1, 1).println('HA NOI XUA').size(0, 0).bold(false)
      .println('Bun rieu - Bun dau')
      .println('220 Nguyen Hoang, An Phu, Thu Duc')
      .println('Tel: 0901 681 567')
      .line()
      .alignLeft()
      .println(`Don: #${orderId}    ${time}`)
      .println(`Ban: ${table || 'Ban ?'}`)
      .line()
      .bold(true)
      .tableRow([
        { text: 'Mon', width: 0.5, align: 'left' },
        { text: 'SL', width: 0.1, align: 'center' },
        { text: 'T.Tien', width: 0.4, align: 'right' },
      ])
      .bold(false).line();

    for (const item of itemList) {
      esc.tableRow([
        { text: item.name, width: 0.5, align: 'left' },
        { text: String(item.qty || 1), width: 0.1, align: 'center' },
        { text: new Intl.NumberFormat('vi-VN').format((item.price || 0) * (item.qty || 1)) + 'd', width: 0.4, align: 'right' },
      ]);
    }

    esc.line()
      .bold(true).size(0, 1)
      .tableRow([
        { text: 'TONG CONG:', width: 0.5, align: 'left' },
        { text: new Intl.NumberFormat('vi-VN').format(total) + 'd', width: 0.5, align: 'right' },
      ])
      .size(0, 0).bold(false)
      .println(`TT: ${paymentMethod === 'transfer' ? 'Chuyen khoan' : 'Tien mat'}`)
      .line()
      .alignCenter()
      .println('Cam on quy khach!')
      .println('Hen gap lai :)')
      .newLine(3).cut();

    const ok = printRaw(printerName, esc.build());
    res.json({ success: ok });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

// --- Web UI ---
app.get('/', (_req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>🖨️ Printer Test Tool</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f0ebe5;color:#1a1412;min-height:100vh}
    .header{background:#1a1412;color:#fff;padding:16px 24px;display:flex;align-items:center;gap:12px}
    .header h1{font-size:18px;font-weight:700}
    .header span{font-size:13px;color:#a0998f}
    .body{padding:20px;max-width:760px;margin:0 auto}
    .card{background:#fff;border-radius:14px;padding:20px;margin-bottom:16px;box-shadow:0 2px 10px rgba(0,0,0,.07)}
    .card-title{font-size:14px;font-weight:700;color:#5a4e46;text-transform:uppercase;letter-spacing:.05em;margin-bottom:14px;display:flex;align-items:center;gap:6px}
    
    /* Printer cards */
    .printers{display:grid;gap:10px}
    .printer-card{border:2px solid #e3ddd6;border-radius:10px;padding:14px 16px;cursor:pointer;display:flex;align-items:center;gap:12px;transition:.15s}
    .printer-card:hover{border-color:#c24b30;background:#fdf9f8}
    .printer-card.selected{border-color:#c24b30;background:#fde8e2}
    .printer-icon{font-size:24px;flex-shrink:0}
    .printer-info{flex:1}
    .printer-name{font-weight:700;font-size:15px;margin-bottom:2px}
    .printer-status{font-size:12px;padding:2px 8px;border-radius:20px;display:inline-block}
    .status-ready{background:#d6ede4;color:#1e6b4f}
    .status-warning{background:#fce0e3;color:#c4303e}
    .printer-check{width:22px;height:22px;border-radius:50%;border:2px solid #d4cbc2;display:flex;align-items:center;justify-content:center;font-size:12px;transition:.15s;flex-shrink:0}
    .printer-card.selected .printer-check{background:#c24b30;border-color:#c24b30;color:#fff}
    .no-printer{text-align:center;padding:24px;color:#7a6e66;font-size:14px}
    
    /* Actions */
    .actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px}
    .btn{display:flex;align-items:center;justify-content:center;gap:8px;padding:14px 16px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;transition:.15s;width:100%}
    .btn:active{transform:scale(.96)}
    .btn:disabled{opacity:.4;cursor:not-allowed}
    .btn-test{background:#c24b30;color:#fff}
    .btn-kitchen{background:#1e6b4f;color:#fff}
    .btn-receipt{background:#2e72ad;color:#fff}
    .btn-refresh{background:#e3ddd6;color:#1a1412}
    
    /* Form */
    label{display:block;font-size:11px;font-weight:700;color:#5a4e46;text-transform:uppercase;letter-spacing:.04em;margin-bottom:4px}
    input,select,textarea{width:100%;padding:10px 12px;border:2px solid #d4cbc2;border-radius:8px;font-size:13px;margin-bottom:10px;font-family:inherit;background:#fff;color:#1a1412}
    input:focus,select:focus,textarea:focus{border-color:#c24b30;outline:none}
    textarea{resize:vertical;min-height:80px}
    .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
    
    /* Log */
    .log{background:#1a1412;color:#a0f0a0;border-radius:8px;padding:12px 14px;font-family:'Courier New',monospace;font-size:12px;max-height:160px;overflow-y:auto;white-space:pre-wrap;line-height:1.6}
    .log-err{color:#ff8080}
    .log-ok{color:#a0f0a0}
    .log-info{color:#ffd080}

    /* Selected printer badge */
    .selected-badge{background:#fde8e2;border:1px solid #f0c4b8;border-radius:8px;padding:8px 12px;font-size:13px;color:#c24b30;font-weight:600;margin-bottom:14px;display:none;align-items:center;gap:6px}
    .selected-badge.show{display:flex}

    @media(max-width:500px){.actions{grid-template-columns:1fr}.grid-2{grid-template-columns:1fr}}
  </style>
</head>
<body>

<div class="header">
  <span style="font-size:28px">🖨️</span>
  <div>
    <h1>Printer Test Tool</h1>
    <span>Hà Nội Xưa — Chọn máy in để test</span>
  </div>
</div>

<div class="body">

  <!-- Printer List -->
  <div class="card">
    <div class="card-title">
      🖨 Máy in khả dụng
      <button class="btn btn-refresh" style="width:auto;padding:6px 12px;font-size:12px;margin-left:auto;border-radius:8px" onclick="loadPrinters()">↻ Tải lại</button>
    </div>
    <div id="printers" class="printers">
      <div class="no-printer">Đang tải danh sách máy in...</div>
    </div>
  </div>

  <!-- Actions -->
  <div class="selected-badge" id="badge">
    <span>🖨️</span>
    <span id="badge-name">Chưa chọn</span>
  </div>

  <div class="card">
    <div class="card-title">⚡ Thao tác nhanh</div>
    <div class="actions">
      <button class="btn btn-test" id="btn-test" onclick="printTest()" disabled>
        🧪 In test (tờ thông tin)
      </button>
      <button class="btn btn-kitchen" id="btn-kitchen" onclick="showSection('kitchen')" disabled>
        📋 In phiếu bếp mẫu
      </button>
    </div>
    <div class="actions">
      <button class="btn btn-receipt" id="btn-receipt" onclick="showSection('receipt')" disabled>
        🧾 In hoá đơn mẫu
      </button>
      <div></div>
    </div>
  </div>

  <!-- Kitchen Form -->
  <div class="card" id="sec-kitchen" style="display:none">
    <div class="card-title">📋 Phiếu bếp mẫu</div>
    <div class="grid-2">
      <div><label>Bàn</label><input id="k-table" value="Bàn 1" /></div>
      <div><label>Ghi chú</label><input id="k-note" value="Ít cay, không hành" /></div>
    </div>
    <label>Món ăn (mỗi dòng: tên,số lượng)</label>
    <textarea id="k-items">Tô Đặc Biệt,2
Tô Đầy Đủ,1
Trà đá,3</textarea>
    <button class="btn btn-kitchen" onclick="printKitchen()">🖨️ In phiếu bếp</button>
  </div>

  <!-- Receipt Form -->
  <div class="card" id="sec-receipt" style="display:none">
    <div class="card-title">🧾 Hoá đơn mẫu</div>
    <div class="grid-2">
      <div><label>Bàn</label><input id="r-table" value="Bàn 1" /></div>
      <div>
        <label>Thanh toán</label>
        <select id="r-pay">
          <option value="cash">Tiền mặt</option>
          <option value="transfer">Chuyển khoản</option>
        </select>
      </div>
    </div>
    <label>Món ăn (tên,số lượng,đơn giá)</label>
    <textarea id="r-items">Tô Đặc Biệt,2,68000
Tô Đầy Đủ,1,59000
Trà đá,3,10000</textarea>
    <button class="btn btn-receipt" onclick="printReceipt()">🧾 In hoá đơn</button>
  </div>

  <!-- Log -->
  <div class="card">
    <div class="card-title">📜 Log</div>
    <div id="log" class="log">Sẵn sàng. Chọn máy in để bắt đầu...\n</div>
  </div>

</div>

<script>
  let selectedPrinter = null;

  function lg(msg, type = 'ok') {
    const el = document.getElementById('log');
    const t = new Date().toLocaleTimeString('vi-VN');
    el.innerHTML += `<span class="log-${type}">${t}  ${msg}</span>\n`;
    el.scrollTop = el.scrollHeight;
  }

  function showSection(id) {
    document.getElementById('sec-kitchen').style.display = 'none';
    document.getElementById('sec-receipt').style.display = 'none';
    document.getElementById('sec-' + id).style.display = 'block';
    document.getElementById('sec-' + id).scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function selectPrinter(name) {
    selectedPrinter = name;
    document.querySelectorAll('.printer-card').forEach(el => {
      el.classList.toggle('selected', el.dataset.name === name);
      el.querySelector('.printer-check').textContent = el.dataset.name === name ? '✓' : '';
    });
    document.getElementById('badge').classList.add('show');
    document.getElementById('badge-name').textContent = name;
    ['btn-test', 'btn-kitchen', 'btn-receipt'].forEach(id => {
      document.getElementById(id).disabled = false;
    });
    lg('Đã chọn máy in: ' + name, 'info');
  }

  async function loadPrinters() {
    const container = document.getElementById('printers');
    container.innerHTML = '<div class="no-printer">Đang tải...</div>';
    try {
      const d = await fetch('/api/printers').then(r => r.json());
      if (!d.printers?.length) {
        container.innerHTML = '<div class="no-printer">❌ Không tìm thấy máy in nào</div>';
        return;
      }
      container.innerHTML = d.printers.map(p => \`
        <div class="printer-card" data-name="\${p.name}" onclick="selectPrinter('\${p.name.replace(/'/g, "\\\\'")}')">
          <div class="printer-icon">🖨️</div>
          <div class="printer-info">
            <div class="printer-name">\${p.name}</div>
            <span class="printer-status \${p.status === 'ready' ? 'status-ready' : 'status-warning'}">
              \${p.status === 'ready' ? '✅' : '⚠️'} \${p.statusText}
            </span>
          </div>
          <div class="printer-check"></div>
        </div>
      \`).join('');
      lg('Tìm thấy ' + d.printers.length + ' máy in', 'info');
    } catch (err) {
      container.innerHTML = '<div class="no-printer">❌ ' + err.message + '</div>';
    }
  }

  async function printTest() {
    if (!selectedPrinter) return;
    lg('In test → ' + selectedPrinter + '...', 'info');
    const d = await fetch('/api/print-test', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ printerName: selectedPrinter })
    }).then(r => r.json()).catch(e => ({ success: false, error: e.message }));
    lg(d.success ? '✅ In test thành công! Kiểm tra giấy ra.' : '❌ Lỗi: ' + d.error, d.success ? 'ok' : 'err');
  }

  async function printKitchen() {
    if (!selectedPrinter) return;
    const table = document.getElementById('k-table').value;
    const note = document.getElementById('k-note').value;
    const items = document.getElementById('k-items').value.split('\\n').filter(Boolean).map(l => {
      const [name, qty] = l.split(','); return { name: name.trim(), qty: parseInt(qty) || 1 };
    });
    lg('In phiếu bếp → ' + selectedPrinter, 'info');
    const d = await fetch('/api/print-kitchen', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ printerName: selectedPrinter, table, items, note })
    }).then(r => r.json()).catch(e => ({ success: false, error: e.message }));
    lg(d.success ? '✅ Phiếu bếp OK!' : '❌ ' + d.error, d.success ? 'ok' : 'err');
  }

  async function printReceipt() {
    if (!selectedPrinter) return;
    const table = document.getElementById('r-table').value;
    const paymentMethod = document.getElementById('r-pay').value;
    const items = document.getElementById('r-items').value.split('\\n').filter(Boolean).map(l => {
      const [name, qty, price] = l.split(',');
      return { name: name.trim(), qty: parseInt(qty) || 1, price: parseInt(price) || 0 };
    });
    lg('In hoá đơn → ' + selectedPrinter, 'info');
    const d = await fetch('/api/print-receipt', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ printerName: selectedPrinter, table, items, paymentMethod })
    }).then(r => r.json()).catch(e => ({ success: false, error: e.message }));
    lg(d.success ? '✅ Hoá đơn OK!' : '❌ ' + d.error, d.success ? 'ok' : 'err');
  }

  // Load on start
  loadPrinters();
</script>
</body>
</html>`);
});

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════════╗');
  console.log('║  🌐 PRINTER TEST WEB UI              ║');
  console.log('╚══════════════════════════════════════╝');
  console.log(`  URL: http://localhost:${PORT}`);
  console.log('');
  console.log('  Mo browser va chon may in de test!');
  console.log('');
});
