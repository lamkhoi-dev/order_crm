/**
 * printer-core.js
 * 
 * Gửi raw ESC/POS bytes tới Windows printer qua PowerShell.
 * Không cần native module, không cần Python, không cần Build Tools.
 */
import { execSync, execFileSync } from 'child_process';
import { writeFileSync, unlinkSync, existsSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

// --- ESC/POS Command Builder ---
export class EscPos {
  constructor() {
    this.data = [];
  }

  // Raw bytes
  raw(...bytes) {
    this.data.push(...bytes);
    return this;
  }

  // Initialize printer
  init() {
    return this.raw(0x1B, 0x40);
  }

  // Text
  text(str) {
    for (const ch of str) {
      this.data.push(ch.charCodeAt(0));
    }
    return this;
  }

  println(str = '') {
    return this.text(str).raw(0x0A);
  }

  newLine(n = 1) {
    for (let i = 0; i < n; i++) this.raw(0x0A);
    return this;
  }

  // Alignment: 0=left, 1=center, 2=right
  align(a = 0) {
    return this.raw(0x1B, 0x61, a);
  }
  alignLeft() { return this.align(0); }
  alignCenter() { return this.align(1); }
  alignRight() { return this.align(2); }

  // Bold: true/false
  bold(on = true) {
    return this.raw(0x1B, 0x45, on ? 1 : 0);
  }

  // Text size: w=0|1, h=0|1
  size(w = 0, h = 0) {
    const n = (w << 4) | h;
    return this.raw(0x1D, 0x21, n);
  }

  // Draw line (48 dashes)
  line(char = '-', len = 32) {
    return this.println(char.repeat(len));
  }

  // Table row: [{ text, width, align }] — width in chars (total ~32)
  tableRow(cols) {
    const TOTAL = 32;
    let row = '';
    for (const col of cols) {
      const w = Math.round(col.width * TOTAL);
      let t = String(col.text).slice(0, w);
      if (col.align === 'right') t = t.padStart(w);
      else if (col.align === 'center') {
        const pad = Math.floor((w - t.length) / 2);
        t = ' '.repeat(pad) + t + ' '.repeat(w - t.length - pad);
      } else {
        t = t.padEnd(w);
      }
      row += t;
    }
    return this.println(row);
  }

  // Feed and cut
  cut() {
    return this.raw(0x1D, 0x56, 0x41, 0x00);
  }

  // Build Buffer
  build() {
    return Buffer.from(this.data);
  }
}

// --- Windows Raw Print via PowerShell ---

// List all printers
export function listPrinters() {
  try {
    const out = execSync(
      'powershell -NoProfile -Command "Get-Printer | Select-Object Name,PrinterStatus | ConvertTo-Json"',
      { encoding: 'utf8', timeout: 5000 }
    );
    const parsed = JSON.parse(out.trim());
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch {
    return [];
  }
}

// Send raw buffer to printer
export function printRaw(printerName, buffer) {
  const tmpFile = join(tmpdir(), `escpos_${Date.now()}.bin`);
  
  try {
    writeFileSync(tmpFile, buffer);
    
    // PowerShell script: dùng RawPrinterHelper qua P/Invoke
    const ps = `
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class RawPrint {
  [DllImport("winspool.Drv", EntryPoint="OpenPrinterA", SetLastError=true)]
  public static extern bool OpenPrinter(string pPrinterName, out IntPtr phPrinter, IntPtr pDefault);
  [DllImport("winspool.Drv", EntryPoint="ClosePrinter", SetLastError=true)]
  public static extern bool ClosePrinter(IntPtr hPrinter);
  [DllImport("winspool.Drv", EntryPoint="StartDocPrinterA", SetLastError=true)]
  public static extern int StartDocPrinter(IntPtr hPrinter, int Level, ref DOCINFOA pDocInfo);
  [DllImport("winspool.Drv", EntryPoint="EndDocPrinter", SetLastError=true)]
  public static extern bool EndDocPrinter(IntPtr hPrinter);
  [DllImport("winspool.Drv", EntryPoint="StartPagePrinter", SetLastError=true)]
  public static extern bool StartPagePrinter(IntPtr hPrinter);
  [DllImport("winspool.Drv", EntryPoint="EndPagePrinter", SetLastError=true)]
  public static extern bool EndPagePrinter(IntPtr hPrinter);
  [DllImport("winspool.Drv", EntryPoint="WritePrinter", SetLastError=true)]
  public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);
  [StructLayout(LayoutKind.Sequential)]
  public struct DOCINFOA {
    [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
    [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
    [MarshalAs(UnmanagedType.LPStr)] public string pDataType;
  }
  public static bool SendFileToPrinter(string printerName, string fileName) {
    IntPtr hPrinter;
    DOCINFOA di = new DOCINFOA();
    di.pDocName = "POS Print";
    di.pDataType = "RAW";
    bool success = OpenPrinter(printerName, out hPrinter, IntPtr.Zero);
    if (!success) return false;
    StartDocPrinter(hPrinter, 1, ref di);
    StartPagePrinter(hPrinter);
    byte[] bytes = System.IO.File.ReadAllBytes(fileName);
    IntPtr pBytes = Marshal.AllocCoTaskMem(bytes.Length);
    Marshal.Copy(bytes, 0, pBytes, bytes.Length);
    int written;
    WritePrinter(hPrinter, pBytes, bytes.Length, out written);
    Marshal.FreeCoTaskMem(pBytes);
    EndPagePrinter(hPrinter);
    EndDocPrinter(hPrinter);
    ClosePrinter(hPrinter);
    return written == bytes.Length;
  }
}
"@
$result = [RawPrint]::SendFileToPrinter("${printerName}", "${tmpFile.replace(/\\/g, '\\\\')}")
if ($result) { Write-Output "OK" } else { Write-Output "FAIL" }
`;

    const result = execFileSync('powershell', ['-NoProfile', '-Command', ps], {
      encoding: 'utf8',
      timeout: 10000,
    }).trim();

    return result === 'OK';
  } finally {
    if (existsSync(tmpFile)) {
      try { unlinkSync(tmpFile); } catch {}
    }
  }
}
